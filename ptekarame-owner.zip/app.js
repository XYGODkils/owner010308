(() => {
'use strict';
const $ = s => document.querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => '&#' + c.charCodeAt(0) + ';');
const when = t => t ? new Date(t).toLocaleString('id-ID') : '-';
let D = null;

async function api(a, b) {
  try {
    const r = await fetch('/api/owner', {
      method: 'POST', credentials: 'same-origin',
      headers: { 'content-type': 'application/json', 'x-o': '1' },
      body: JSON.stringify(Object.assign({ a }, b || {}))
    });
    const j = await r.json().catch(() => ({}));
    j.status = r.status;
    if (r.status === 401 && j.err === 'auth') lock();
    return j;
  } catch (e) { return { err: 'net', msg: 'Jaringan bermasalah' }; }
}

const say = (id, t, ok) => { const f = $(id); f.textContent = t || ''; f.style.color = ok ? '#8fd19e' : '#e08a8a'; };
const show = id => document.querySelectorAll('.screen').forEach(s => s.classList.toggle('on', s.id === id));
const lock = () => show('login');

async function login() {
  const j = await api('login', { pw: $('#pw').value });
  if (!j.ok) return say('#lf', j.msg || 'Gagal masuk', 0);
  $('#pw').value = '';
  say('#lf', '');
  show('panel');
  load();
}
$('#go').onclick = login;
$('#pw').addEventListener('keydown', e => { if (e.key === 'Enter') login(); });
$('#out').onclick = async () => { await api('logout'); lock(); };
$('#rf').onclick = () => load();

document.querySelectorAll('#tabs button').forEach(b => {
  b.onclick = () => {
    document.querySelectorAll('#tabs button').forEach(x => x.classList.toggle('on', x === b));
    document.querySelectorAll('.view').forEach(v => v.classList.toggle('on', v.id === 'v-' + b.dataset.t));
  };
});

async function load() {
  const j = await api('all');
  if (j.err) return;
  D = j;
  render();
}

const none = t => `<p class="empty">${t}</p>`;

function render() {
  const pend = D.appeals.filter(x => x.s === 'p');
  $('#n-ap').textContent = pend.length || '';
  $('#n-od').textContent = D.orders.length || '';
  $('#v-ap').innerHTML = D.appeals.length ? D.appeals.map((a, i) => `
    <div class="item glass" style="animation-delay:${i * .04}s">
      <div class="hd"><b>${esc(a.code)}</b><span class="tag">${a.s === 'p' ? 'Menunggu' : a.s === 'a' ? 'Diterima' : 'Ditolak'}</span></div>
      <div class="mt">Penanda: <span class="tag">${esc(a.lbl)}</span><br>IP saat banding: ${esc(a.ip)}<br>IP saat ban: ${esc(a.ipBan)}<br>Detail sistem: ${esc(a.d) || '-'}<br>Alasan pemain: ${esc(a.why) || '-'}<br>${when(a.t)}</div>
      ${a.s === 'p' ? `<div class="acts"><button class="btn main sm" data-ap="${esc(a.id)}" data-ok="1"><i class="fa-solid fa-check"></i>Terima</button><button class="btn sm" data-ap="${esc(a.id)}" data-ok="0"><i class="fa-solid fa-xmark"></i>Tolak</button></div>` : ''}
    </div>`).join('') : none('Belum ada pengajuan');

  const ks = Object.keys(D.codes).sort();
  $('#l-cd').innerHTML = ks.length ? ks.map((k, i) => {
    const c = D.codes[k];
    return `<div class="item glass" style="animation-delay:${i * .04}s">
      <div class="hd"><b>${esc(k)}</b><div class="acts"><button class="btn sm" data-cr="${esc(k)}" aria-label="Reset"><i class="fa-solid fa-rotate-left"></i></button><button class="btn sm" data-cd="${esc(k)}" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button></div></div>
      <div class="mt">${c.t === 'p' ? '+' + esc(c.n) + ' poin' : 'Pesan: ' + esc(c.x)}<br>Versi ${esc(c.v || 0)}, dipakai ${esc(c.u || 0)}${c.mx ? ' dari ' + esc(c.mx) : ''}</div>
    </div>`;
  }).join('') : none('Belum ada kode');

  $('#v-od').innerHTML = D.orders.length ? D.orders.map((o, i) => `
    <div class="item glass" style="animation-delay:${i * .04}s">
      <div class="hd"><b>${esc(o.i)}</b><button class="btn sm" data-od="${esc(o.id)}" aria-label="Selesai"><i class="fa-solid fa-check"></i></button></div>
      <div class="mt"><a href="${/^https:\/\/(www\.)?whatsapp\.com\/channel\//i.test(o.l) ? esc(o.l) : '#'}" target="_blank" rel="noopener noreferrer" style="color:inherit">${esc(o.l)}</a><br>${esc(o.p)} poin, IP ${esc(o.ip)}<br>${when(o.t)}</div>
    </div>`).join('') : none('Belum ada pesanan');

  $('#l-bn').innerHTML = D.bans.length ? D.bans.map((b, i) => `
    <div class="item glass" style="animation-delay:${i * .04}s">
      <div class="hd"><b>${esc(b.code)}</b><button class="btn sm" data-ub="${esc(b.code)}"><i class="fa-solid fa-lock-open"></i>Cabut</button></div>
      <div class="mt">Penanda: <span class="tag">${esc(({CHEAT_POINTS:'Poin tidak wajar',AUTOPLAY:'Pola auto play',TAMPER:'Request dimanipulasi',BOOKMARK:'Masuk lewat bookmark berulang',IP_ROTATE:'IP berganti-ganti saat redeem',BRUTE:'Menebak kode redeem',MANUAL:'Ban manual dari owner'})[b.r] || b.r)}</span><br>IP: ${esc(b.ip)}<br>Detail: ${esc(b.d) || '-'}<br>${when(b.t)}${b.ap === 1 ? '<br>Sudah mengajukan banding' : ''}</div>
    </div>`).join('') : none('Tidak ada IP yang diblokir');

  $('#v-lg').innerHTML = `<div class="acts" style="margin-bottom:12px"><button class="btn sm" id="lc"><i class="fa-solid fa-broom"></i>Bersihkan log</button></div>` +
    (D.ev.length ? D.ev.map(e => `<div class="item glass"><div class="hd"><b>${esc(e.k)}</b><span class="mt">${when(e.t)}</span></div><div class="mt">${esc(e.ip) || ''} ${esc(e.r) || ''} ${esc(e.d) || ''} ${esc(e.code) || ''}</div></div>`).join('') : none('Log kosong'));
}

document.addEventListener('click', async e => {
  const t = e.target.closest('button');
  if (!t) return;
  let j = null;
  if (t.dataset.ap) j = await api('appealAct', { id: t.dataset.ap, ok: t.dataset.ok === '1' });
  else if (t.dataset.cr) j = await api('codeReset', { k: t.dataset.cr });
  else if (t.dataset.cd) j = await api('codeDel', { k: t.dataset.cd });
  else if (t.dataset.od) j = await api('orderDel', { id: t.dataset.od });
  else if (t.dataset.ub) j = await api('unban', { code: t.dataset.ub });
  else if (t.id === 'lc') j = await api('evClear');
  if (j) load();
});

$('#ct').onchange = () => {
  const p = $('#ct').value === 'p';
  $('#cn').hidden = !p;
  $('#cx').hidden = p;
};
$('#cs').onclick = async () => {
  const j = await api('codeSet', { k: $('#ck').value, t: $('#ct').value, n: $('#cn').value, x: $('#cx').value, mx: $('#cm').value });
  say('#cf', j.msg || (j.ok ? 'Tersimpan' : 'Gagal'), j.ok);
  if (j.ok) { $('#ck').value = ''; $('#cn').value = ''; $('#cx').value = ''; $('#cm').value = ''; load(); }
};
$('#bb').onclick = async () => {
  const j = await api('banIp', { ip: $('#bi').value, why: $('#bw').value });
  say('#bf', j.msg || (j.ok ? 'Tersimpan' : 'Gagal'), j.ok);
  if (j.ok) { $('#bi').value = ''; $('#bw').value = ''; load(); }
};

(async () => {
  const j = await api('all');
  if (!j.err) { D = j; show('panel'); render(); }
})();
})();
