const L = require('./_lib');

const cl = s => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 24);
const LABEL = { MANUAL: 'Ban manual dari owner' };

async function unban(code) {
  const bc = await L.val('bc/' + code);
  if (!bc) return false;
  const u = {};
  for (const pid of Object.keys(bc.pids || {})) {
    u['bans/pid/' + pid] = null;
    const p = await L.val('players/' + pid);
    if (p) {
      const perf = p.perf || 0;
      const earn = Math.min(p.earn || 0, perf * 100);
      const exp = earn + (p.red || 0) - (p.spent || 0);
      u['players/' + pid + '/earn'] = earn;
      if ((p.pts || 0) > exp) u['players/' + pid + '/pts'] = Math.max(0, exp);
      u['players/' + pid + '/sk'] = null;
      u['players/' + pid + '/wn'] = null;
    }
  }
  for (const ik of Object.keys(bc.iks || {})) u['bans/ip/' + ik] = null;
  for (const fp of Object.keys(bc.fps || {})) u['bans/fp/' + fp] = null;
  u['bc/' + code] = null;
  u['apidx/' + code] = null;
  await L.db().ref().update(u);
  return true;
}

async function reject(code) {
  const bc = await L.val('bc/' + code);
  if (!bc) return;
  const u = {};
  Object.keys(bc.pids || {}).forEach(p => { u['bans/pid/' + p + '/ap'] = 2; });
  Object.keys(bc.iks || {}).forEach(k => { u['bans/ip/' + k + '/ap'] = 2; });
  await L.db().ref().update(u);
}

async function lastEv() {
  const s = await L.db().ref('ev').orderByKey().limitToLast(80).once('value');
  const o = s.val() || {};
  return Object.keys(o).sort().reverse().map(k => o[k]);
}

module.exports = async (req, res) => {
  if (!L.guard(req, res)) return;
  const b = req.body || {};
  const d = L.db();

  if (b.a === 'login') {
    const ik = L.netKey(L.ipOf(req)), ref = d.ref('ol/' + ik);
    const cur = (await ref.once('value')).val() || {};
    if (cur.l && cur.l > Date.now()) return res.status(429).json({ err: 'lock', msg: 'Terkunci sementara, coba lagi nanti.' });
    if (!L.PASS || !L.eq(L.sha(b.pw), L.sha(L.PASS))) {
      const n = (cur.n || 0) + 1;
      await ref.set(n >= 5 ? { n: 0, l: Date.now() + 15 * 60000 } : { n, l: 0 });
      return res.status(401).json({ err: 'pw', msg: 'Kata sandi salah' });
    }
    await ref.remove();
    L.setCookie(res, L.mkSess(), 21600);
    return res.json({ ok: 1 });
  }

  if (!L.okSess(req)) return res.status(401).json({ err: 'auth' });

  if (b.a === 'logout') { L.setCookie(res, '', 0); return res.json({ ok: 1 }); }

  if (b.a === 'all') {
    const [codes, orders, appeals, bans, ev] = await Promise.all([
      L.val('codes'), L.val('orders'), L.val('appeals'), L.val('bans/pid'), lastEv()
    ]);
    const ap = Object.keys(appeals || {}).map(k => Object.assign({ id: k }, appeals[k])).sort((x, y) => y.t - x.t);
    const bn = Object.keys(bans || {}).map(k => bans[k]).sort((x, y) => y.t - x.t);
    const bi = (await L.val('bans/ip')) || {};
    Object.keys(bi).forEach(k => {
      if (!bn.some(x => x.code === bi[k].code)) bn.push(bi[k]);
    });
    return res.json({
      codes: codes || {},
      orders: Object.keys(orders || {}).sort().map(k => Object.assign({ id: k }, orders[k])),
      appeals: ap, bans: bn, ev
    });
  }

  if (b.a === 'codeSet') {
    const k = cl(b.k), t = b.t === 'm' ? 'm' : 'p';
    if (k.length < 3) return res.json({ err: 1, msg: 'Teks kode minimal 3 huruf atau angka' });
    const old = (await L.val('codes/' + k)) || {};
    const o = { t, v: old.v || 0, u: old.u || 0, mx: Math.max(0, Math.floor(Number(b.mx) || 0)) };
    if (t === 'p') {
      o.n = Math.floor(Number(b.n));
      if (!(o.n > 0 && o.n <= 100000)) return res.json({ err: 1, msg: 'Jumlah poin harus 1 sampai 100000' });
    } else {
      o.x = String(b.x || '').trim().slice(0, 200);
      if (!o.x) return res.json({ err: 1, msg: 'Isi pesan yang akan muncul' });
    }
    await d.ref('codes/' + k).set(o);
    return res.json({ ok: 1, msg: 'Kode ' + k + (old.t ? ' diperbarui' : ' dibuat') });
  }

  if (b.a === 'codeReset') {
    const k = cl(b.k), c = await L.val('codes/' + k);
    if (c) await d.ref('codes/' + k).update({ v: (c.v || 0) + 1, u: 0 });
    return res.json({ ok: 1 });
  }
  if (b.a === 'codeDel') { await d.ref('codes/' + cl(b.k)).remove(); return res.json({ ok: 1 }); }
  if (b.a === 'orderDel') { await d.ref('orders/' + String(b.id).replace(/[^A-Za-z0-9]/g, '')).remove(); return res.json({ ok: 1 }); }

  if (b.a === 'appealAct') {
    const id = String(b.id).replace(/[^A-Za-z0-9]/g, '');
    const ap = await L.val('appeals/' + id);
    if (!ap) return res.json({ err: 1, msg: 'Pengajuan tidak ditemukan' });
    if (b.ok) await unban(ap.code); else await reject(ap.code);
    await d.ref('appeals/' + id + '/s').set(b.ok ? 'a' : 'x');
    return res.json({ ok: 1 });
  }

  if (b.a === 'unban') { await unban(String(b.code).replace(/[^A-Z0-9-]/g, '')); return res.json({ ok: 1 }); }

  if (b.a === 'banIp') {
    const ip = String(b.ip || '').trim().slice(0, 64);
    if (!ip) return res.json({ err: 1, msg: 'Isi alamat IP' });
    const ik = L.netKey(ip);
    const bb = { code: 'BN-' + L.rid(3).toUpperCase(), r: 'MANUAL', pid: 'manual', ip, ik, t: Date.now(), d: String(b.why || '').slice(0, 200), ap: 0 };
    const u = {};
    u['bans/ip/' + ik] = bb;
    u['bc/' + bb.code + '/iks/' + ik] = true;
    await d.ref().update(u);
    return res.json({ ok: 1, msg: 'IP diblokir dengan kode ' + bb.code });
  }

  if (b.a === 'evClear') { await d.ref('ev').remove(); return res.json({ ok: 1 }); }
  res.status(400).json({ err: 'a' });
};
module.exports.LABEL = LABEL;
