const admin = require('firebase-admin');
const crypto = require('crypto');

const SECRET = process.env.OWNER_SECRET || '';
const PASS = process.env.OWNER_PASS || '';
const SESSION = 6 * 3600 * 1000;

function db() {
  if (!admin.apps.length) {
    const sa = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
    if (sa.private_key) sa.private_key = sa.private_key.replace(/\\n/g, '\n');
    admin.initializeApp({ credential: admin.credential.cert(sa), databaseURL: process.env.FIREBASE_DB_URL });
  }
  return admin.database();
}

const val = async p => (await db().ref(p).once('value')).val();
const sig = s => crypto.createHmac('sha256', SECRET).update(s).digest('base64url');
const eq = (a, b) => {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};
const sha = s => crypto.createHash('sha256').update(String(s)).digest('hex');
const rid = n => crypto.randomBytes(n).toString('hex');
const ikey = ip => String(ip || 'x').replace(/[^A-Za-z0-9]/g, '_');
const v6 = ip => {
  const a = String(ip).split('::');
  const h = a[0] ? a[0].split(':') : [], t = a[1] ? a[1].split(':') : [];
  const f = h.concat(Array(Math.max(0, 8 - h.length - t.length)).fill('0'), t);
  return f.slice(0, 4).map(x => x.padStart(4, '0')).join(':');
};
const netKey = ip => (String(ip || '').includes(':') ? 'v6_' + ikey(v6(ip)) : ikey(ip));
const ipOf = req => String(
  req.headers['x-vercel-forwarded-for'] || req.headers['x-real-ip'] || req.headers['x-forwarded-for'] ||
  (req.socket && req.socket.remoteAddress) || ''
).split(',')[0].trim();

const cookies = req => {
  const o = {};
  String(req.headers.cookie || '').split(';').forEach(s => {
    const i = s.indexOf('=');
    if (i > 0) o[s.slice(0, i).trim()] = s.slice(i + 1).trim();
  });
  return o;
};
const setCookie = (res, v, age) =>
  res.setHeader('Set-Cookie', `tr_o=${v}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${age}`);

const mkSess = () => {
  const t = String(Date.now());
  return t + '.' + sig('o.' + t);
};
const okSess = req => {
  const a = String(cookies(req).tr_o || '').split('.');
  return a.length === 2 && eq(a[1], sig('o.' + a[0])) && Date.now() - Number(a[0]) < SESSION;
};

function guard(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') { res.status(405).json({ err: 'method' }); return false; }
  let host = '';
  try { host = new URL(req.headers.origin || '').host; } catch (e) {}
  if (!host || host !== req.headers.host || req.headers['x-o'] !== '1') { res.status(403).json({ err: 'origin' }); return false; }
  const allow = (process.env.OWNER_IPS || '').split(',').map(s => s.trim()).filter(Boolean);
  if (allow.length && !allow.includes(ipOf(req))) { res.status(403).json({ err: 'ip' }); return false; }
  return true;
}

module.exports = { db, val, eq, sha, rid, ikey, netKey, ipOf, setCookie, mkSess, okSess, guard, PASS };
