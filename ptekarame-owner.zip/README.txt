TekaRame Owner Panel (project Vercel terpisah)

Deploy sebagai project baru dengan domain yang berbeda dari game. Jangan dibagikan ke pemain.
Memakai Firebase yang sama dengan game, lewat service account yang sama.

Environment variables
   FIREBASE_SERVICE_ACCOUNT = isi JSON service account yang sama dengan game
   FIREBASE_DB_URL          = URL Realtime Database yang sama dengan game
   OWNER_PASS               = kata sandi panel
   OWNER_SECRET             = teks acak panjang (minimal 32 karakter), berbeda dari TR_SECRET game
   OWNER_IPS                = opsional, daftar IP yang boleh masuk, pisahkan dengan koma

Fitur: pengajuan banding (kode ban, IP, penanda, alasan, terima atau tolak), kode redeem, pesanan, daftar ban dan cabut ban, ban IP manual, log kejadian.
Login dikunci 15 menit setelah 5 kali salah. Sesi berlaku 6 jam.
Saat banding diterima, poin yang melebihi riwayat dikembalikan ke nilai wajar.
